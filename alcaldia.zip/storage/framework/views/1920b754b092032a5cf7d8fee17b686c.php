<?php echo e($slot); ?>

<?php /**PATH C:\Users\ODAR_17\Desktop\Ingenieria\IS802-IPAC2024\alcaldias\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>